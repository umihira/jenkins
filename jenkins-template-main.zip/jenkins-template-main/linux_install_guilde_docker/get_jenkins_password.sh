#!/bin/bash
docker exec jenkins cat /var/jenkins_home/secrets/initialAdminPassword